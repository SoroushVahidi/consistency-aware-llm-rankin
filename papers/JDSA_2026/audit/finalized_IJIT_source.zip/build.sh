#!/usr/bin/env bash
set -euo pipefail
document_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$document_root"
mkdir -p build
export TEXINPUTS="$document_root:${TEXINPUTS:-}"
export BSTINPUTS="$document_root:${BSTINPUTS:-}"
for document_name in main supplement; do
  pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build "$document_name.tex" >"build/$document_name.console.log" 2>&1
  bibtex "build/$document_name" >>"build/$document_name.console.log" 2>&1
  for build_pass in 2 3 4; do
    pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build "$document_name.tex" >>"build/$document_name.console.log" 2>&1
  done
  cp "build/$document_name.pdf" "$document_name.pdf"
done
